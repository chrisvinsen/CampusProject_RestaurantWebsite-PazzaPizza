

<?php $__env->startSection('custom_css'); ?>
<!-- Nice Select -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nice-select/nice-select.css')); ?>">
<!-- Nouislider -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nouislider/nouislider.min.css')); ?>">
<!-- Sweetalert -->
<link rel="stylesheet" href="<?php echo e(asset('css/cms/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- All Content -->
<!-- ================ Menu Banner start ================= -->   
<section class="blog-banner-area" id="category" >
    <div class="h-100" style="background-image: url('<?php echo e(asset('images/cms/menu_banner.jpg')); ?>'); background-repeat:no-repeat; -webkit-background-size:cover; -moz-background-size:cover; -o-background-size:cover; background-size:cover; background-position:center;">
        <div class="container-fluid h-100" >
            <div class="blog-banner">
                <div class="text-center">
                    <h1 style="color: #FBFBFB; text-shadow: 2px 2px #ED262A;">M E N U</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================ Menu Banner end ================= -->
<!-- ================ Category section start ================= -->        
<section class="section-margin--small mb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-4 col-md-5">
                <div class="sidebar-categories">
                    <div class="head">Filter Menu</div>
                    <ul class="main-categories">
                        <li class="common-filter">
                            <h5 class="text-secondary">Category</h5>
                            <ul>
                                <li class="filter-list"><input class="pixel-radio" type="radio" id="All" name="category" value="" <?php if(app('request')->input('category') == ""): ?> checked <?php endif; ?>><span for="All">Show All<span class="float-right"></span></span></li>
                                <?php if(sizeof($category_lists) > 0 && sizeof($all_product_lists) > 0): ?>
                                <?php $__currentLoopData = $category_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->total_product > 0): ?>
                                <li class="filter-list"><input class="pixel-radio" type="radio" id="<?php echo e($category->name); ?>" name="category" value="<?php echo e($category->id); ?>" <?php if(app('request')->input('category') == $category->id): ?> checked <?php endif; ?>><span for="<?php echo e($category->name); ?>"><?php echo e($category->name); ?><span class="float-right"> <?php echo e($category->total_product); ?> </span></span></li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <span>No Records</span>
                                <?php endif; ?>
                            </ul>
                            <hr>
                            <h5 class="text-secondary">Price</h5>
                            <div class="form-group input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        Rp
                                    </div>
                                </div>
                                <input type="text" class="form-control" id="min_price" name="min_price" placeholder="Minimum Price" value="<?php echo e(app('request')->input('min_price')); ?>">
                            </div>
                            <div class="form-group input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        Rp
                                    </div>
                                </div>
                                <input type="text" class="form-control" id="max_price" name="max_price" placeholder="Maximum Price" value="<?php echo e(app('request')->input('max_price')); ?>">
                            </div>
                            <div class="pt-5 text-center">
                                <button type="button" class="btn btn-outline-danger px-5" id="filter-id"> Filter </button>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9 col-lg-8 col-md-7">
                <!-- Start Filter Bar -->
                <div class="filter-bar d-flex flex-wrap align-items-center">
                    <div class="sorting">
                        <select name="sorting" id="sorting-id">
                            <option value="" selected>Sorting</option>
                            <option value="name_asc" <?php if( app('request')->input('sorting') == "name_asc"): ?> selected <?php endif; ?>>Name ASC</option>
                            <option value="name_desc" <?php if( app('request')->input('sorting') == "name_desc"): ?> selected <?php endif; ?>>Name DESC</option>
                            <option value="price_asc" <?php if( app('request')->input('sorting') == "price_asc"): ?> selected <?php endif; ?>>Lowest price</option>
                            <option value="price_desc" <?php if( app('request')->input('sorting') == "price_desc"): ?> selected <?php endif; ?>>Highest price</option>
                            <option value="created_asc" <?php if( app('request')->input('sorting') == "created_asc"): ?> selected <?php endif; ?>>Oldest</option>
                            <option value="created_desc" <?php if( app('request')->input('sorting') == "created_desc"): ?> selected <?php endif; ?>>Newest</option>
                        </select>
                    </div>
                    <div class="sorting mr-auto">
                        <select name="paginate" id="paginate-id">
                            <option value="" selected>Pagination</option>
                            <option value="20" <?php if( app('request')->input('paginate') == 20): ?> selected <?php endif; ?>>Paginate 20</option>
                            <option value="40" <?php if( app('request')->input('paginate') == 40): ?> selected <?php endif; ?>>Paginate 40</option>
                            <option value="60" <?php if( app('request')->input('paginate') == 60): ?> selected <?php endif; ?>>Paginate 60</option>
                        </select>
                    </div>
                    <div>
                        <div class="input-group filter-bar-search">
                            <input type="text" maxlength="100" name="search" id="search-id" placeholder="Search" value="<?php echo e(app('request')->input('search')); ?>">
                            <div class="input-group-append">
                                <button type="button" id="search_button-id"><i class="ti-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Filter Bar -->
                <!-- Start Best Seller -->
                <section class="lattest-product-area pb-40 category-list">
                    <div class="row">
                    <?php if(sizeof($product_lists) > 0): ?>
                    <?php $__currentLoopData = $product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card text-center card-product">
                                <div class="card-product__img">
                                    <img class="card-img" src="<?php echo e(asset($product->image_url)); ?>" alt="">
                                    <ul class="card-product__imgOverlay">
                                        <a href="<?php echo e(route('menu.details', $product->id)); ?>">
                                            <li>
                                                <button>
                                                    <i class="ti-search"></i>
                                                </button>
                                            </li>
                                        </a>
                                        <?php if($product->stock > 0): ?>
                                        <a href="javascript:void(0)" onclick="addToCart(<?php echo e($product->id); ?>)">
                                            <li>
                                                <button>
                                                    <i class="ti-shopping-cart"></i>
                                                </button>
                                            </li>
                                        </a>
                                        <?php endif; ?>
                                        <a href="javascript:void(0)" onclick="addToFavorite(<?php echo e($product->id); ?>)">
                                            <li>
                                                <button>
                                                    <i class="ti-heart"></i>
                                                </button>
                                            </li>
                                        </a>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <p><?php echo e($product->category->name); ?></p>
                                    <h4 class="card-product__title"><a href="#"><?php echo e($product->name); ?></a></h4>
                                    <p class="card-product__price"> Rp <?php echo e(number_format($product->price,0,",",".")); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <div class="w-100 text-center">
                        <span>No Records</span>
                    </div>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <div class="float-right">
                            <?php echo e($product_lists->appends(['search' => app('request')->input('search'), 'paginate' => app('request')->input('paginate'), 'sorting' => app('request')->input('sorting'), 'category' => app('request')->input('category'), 'min_price' => app('request')->input('min_price'), 'max_price' => app('request')->input('max_price')])->links()); ?>

                        </div>
                    </div>
                </section>
                <!-- End Best Seller -->
            </div>
        </div>
    </div>
</section>
<!-- ================ Category section end ================= -->          
<!-- ================ Quote section start ================= -->
<section class="subscribe-position">
    <div class="container">
        <div class="subscribe text-center">
            <h3 class="subscribe__title">You Cant' Buy HAPPINESS, <br>But You Can Buy PIZZA <br>And That's Kind of The Same Thing</h3>
            <a class="button button-subscribe mr-auto mb-0 mt-3" href="<?php echo e(route('menu')); ?>">Order Now</a>
        </div>
    </div>
</section>
<!-- ================ Quote section end ================= -->
<!-- End of all content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>   
<!-- Nouislider -->
<script src="<?php echo e(asset('plugins/nouislider/nouislider.min.js')); ?>"></script>
<!-- Jquery Mask -->
<script src="<?php echo e(asset('js/cms/jquery.mask.min.js')); ?>"></script>
<!-- Sweetalert -->
<script src="<?php echo e(asset('js/cms/sweetalert.min.js')); ?>"></script>
<!-- Custom JS -->
<script>
    $(function() {
        $("#min_price").mask('000000000');
        $("#max_price").mask('000000000');

        $("select#paginate-id").on('change', function(){
        //     $("#form-paginate").submit();
            sorting_product();
        })

        $("select#sorting-id").on('change', function(){
        //     $("#form-sorting").submit();
            sorting_product();
        })

        $("#filter-id").on('click', function(){
            sorting_product();
        })

        $("#search_button-id").on('click', function(){
            sorting_product();
        })
    });

    function sorting_product(){
        var category = $("input[name='category']:checked").val();
        var min_price = $("#min_price").val();
        var max_price = $("#max_price").val();
        var sorting = $("#sorting-id").val();
        var paginate = $("#paginate-id").val();
        var search = $("#search-id").val();

        var currentPageUrl = $(location).attr("href").split("?")[0];

        var newPageUrl = `${currentPageUrl}?`;

        if(category){
            newPageUrl += `category=${category}&`;
        }
        if(min_price){
            newPageUrl += `min_price=${min_price}&`;
        }
        if(max_price){
            newPageUrl += `max_price=${max_price}&`;
        }
        if(sorting){
            newPageUrl += `sorting=${sorting}&`;
        }
        if(paginate){
            newPageUrl += `paginate=${paginate}&`;
        }
        if(search){
            newPageUrl += `search=${search}&`;
        }

        newPageUrl = newPageUrl.substr(0, newPageUrl.length-1);

        window.location.href = `${newPageUrl}`;
    }

    function addToFavorite(idx) {

        data = new FormData();

        var url = "<?php echo e(route('account.favorite.store')); ?>";

        data.append('product_id', idx);

        $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            ajaxRequest = $.ajax({
                url: url,
                type: "POST",
                data: data,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data) {
                        swal({
                            title : "Success!", 
                            text: "Product Added to Favorite.", 
                            type: "success"
                        });
                        window.location.reload(true);
                    }
                },
                error: function(request, status, error) {
                    if (request.statusText == 'abort') {
                        return;
                    }
                    swal({
                        title : "Info!", 
                        text: request.responseJSON.messages, 
                        type: "info"
                    }, function(){
                        if(request.responseJSON.status == "login"){
                            window.top.location.href = "<?php echo e(route('account.login')); ?>"
                        }
                    });
                }
            });
    }

    function addToCart(idx) {

        data = new FormData();

        var url = "<?php echo e(route('menu.order.cart.store')); ?>";

        data.append('product_id', idx);
        data.append('quantity_order', 1);

        $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            ajaxRequest = $.ajax({
                url: url,
                type: "POST",
                data: data,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data) {
                        swal({
                            title : "Success!", 
                            text: "Product Added to Cart.", 
                            type: "success"
                        });
                        window.location.reload(true);
                    }
                },
                error: function(request, status, error) {
                    if (request.statusText == 'abort') {
                        return;
                    }
                    swal({
                        title : "Info!", 
                        text: request.responseJSON.messages, 
                        type: "info"
                    }, function(){
                        window.top.location.href = "<?php echo e(route('account.login')); ?>"
                    });
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('cms.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/cms/menu.blade.php ENDPATH**/ ?>