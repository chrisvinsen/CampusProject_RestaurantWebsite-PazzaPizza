

<?php $__env->startSection('custom_css'); ?>
<!-- Nice Select -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nice-select/nice-select.css')); ?>">
<!-- Nouislider -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nouislider/nouislider.min.css')); ?>">
<style>
    .fa.fa-star{
        color: #fbd600;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- All Content -->
<!-- ================ start banner area ================= -->   
<section class="blog-banner-area" id="category">
    <div class="h-100" style="background-image: url('<?php echo e(asset('images/cms/history_banner.jpg')); ?>'); background-repeat:no-repeat; -webkit-background-size:cover; -moz-background-size:cover; -o-background-size:cover; background-size:cover; background-position:center;">
        <div class="blog-banner">
            <div class="text-center">
                <h1 style="color: #FBFBFB; text-shadow: 2px 2px #ED262A;">HISTORY &nbsp TRANSACTION</h1>
            </div>
        </div>
    </div>
</section>
<!-- ================ end banner area ================= -->
<!--================History Area =================-->
<section class="cart_area">
    <div class="container">
        <div class="cart_inner">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th width="100">Transaction ID</th>
                            <th scope="col">Date</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Price</th>
                            <th scope="col">Review</th>
                            <th scope="col">Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(sizeof($transaction_lists) > 0): ?>
                        <?php $__currentLoopData = $transaction_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <h5><?php echo e($key+1); ?></h5>
                            </td>
                            <td>
                                <h5><?php echo e($transaction->id); ?></h5>
                            </td>
                            <td>
                                <h5><?php echo e(date_format($transaction->created_at, 'M, d Y, H:i:s')); ?></h5>
                            </td>
                            <td>
                                <h5>Qty</h5>
                            </td>
                            <td></td>
                            <td></td>
                            <td>
                                <h5>Rp <?php echo e(number_format($transaction->total,0,",",".")); ?></h5>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td colspan="2" >
                                <div class="media">
                                    <div class="d-flex">
                                        <img width="75px" src="<?php echo e($data->product->image_url); ?>" alt="">
                                    </div>
                                    <div class="media-body">
                                        <p><?php echo e($data->product->name); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php echo e($data->quantity_order); ?>

                            </td>
                            <td>
                                Rp <?php echo e(number_format($data->product->price,0,",",".")); ?>

                            </td>
                            <td>
                                <?php if($data->review_id): ?>
                                <?php if($data->review->rating == 5): ?>
                                    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
                                <?php elseif($data->review->rating == 4): ?>
                                    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i>
                                <?php elseif($data->review->rating == 3): ?>
                                    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                <?php elseif($data->review->rating == 2): ?>
                                    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                <?php elseif($data->review->rating == 1): ?>
                                    <i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('menu.details', $data->product->id)); ?>" class="text-danger">Review Now</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                Rp <?php echo e(number_format($data->product->price * $data->quantity_order,0,",",".")); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">No history transaction record</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="p-3">
                    <div class="float-right">
                        <?php echo e($transaction_lists->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End History Area =================-->
<!-- End of all content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/cms/history.blade.php ENDPATH**/ ?>