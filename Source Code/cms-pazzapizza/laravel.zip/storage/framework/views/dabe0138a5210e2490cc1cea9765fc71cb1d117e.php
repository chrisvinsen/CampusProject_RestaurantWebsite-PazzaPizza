

<?php $__env->startSection('custom_css'); ?>
<!-- Nice Select -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nice-select/nice-select.css')); ?>">
<!-- Nouislider -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/nouislider/nouislider.min.css')); ?>">
<!-- Bootstrap Select -->
<link rel="stylesheet" href="<?php echo e(asset('css/cms/bootstrap-select.min.css')); ?>">
<!-- Dropify -->
<link rel="stylesheet" href="<?php echo e(asset('css/cms/dropify.min.css')); ?>">
<!-- Sweetalert -->
<link rel="stylesheet" href="<?php echo e(asset('css/cms/sweetalert.css')); ?>">
<style>
    .stroke-transparent {
        -webkit-text-stroke: 0.3px black;
        -webkit-text-fill-color: transparent;
    }
    .fa.fa-star{
        color: #fbd600;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-wrapper'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"> Dashboard </h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Panel</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">Graph of Total Sales this Month</h3>
                                <a href="javascript:void(0);"><?php echo date('F Y'); ?></a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="d-flex">
                                <p class="d-flex flex-column">
                                    <span>Total Sales (Quantity)</span>
                                </p>
                            </div>
                            <!-- /.d-flex -->
                            <div class="position-relative mb-2">
                                <canvas id="sales-chart" height="200"></canvas>
                            </div>
                            <div class="d-flex flex-row justify-content-end">
                                <span>Date of Month</span>
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Income Lists in <?php echo date('F Y'); ?></h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Quantity</th>
                                        <th>Income</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(sizeof($sales_of_month) > 0): ?>
                                    <span class="d-none"><?php echo e($i = 1); ?></span>
                                    <?php $__currentLoopData = $sales_of_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($key); ?> <?php echo date('F Y'); ?></td>
                                        <td id="qty<?php echo e($key); ?>"></td>
                                        <td id="income<?php echo e($key); ?>"></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No Sales Record</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Sales Record</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th width="50">#</th>
                                        <th width="200">Date & Time</th>
                                        <th>Customer Name</th>
                                        <th>Product Name</th>
                                        <th width="100">Quantity</th>
                                        <th width="160">Total Price</th>
                                        <th width="160">Review</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(sizeof($sales_lists) > 0): ?>
                                    <?php $__currentLoopData = $sales_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e(date_format($record->created_at, 'M, d Y - H:i:s')); ?></td>
                                        <td><?php echo e($record->transaction->user->firstname); ?> <?php echo e($record->transaction->user->lastname); ?></td>
                                        <td><?php echo e($record->product->name); ?></td>
                                        <td><?php echo e($record->quantity_order); ?></td>
                                        <td> Rp <?php echo e(number_format($record->product->price * $record->quantity_order,0,",",".")); ?></td>
                                        <td>
                                            <?php if($record->review_id): ?>
                                            <?php if($record->review->rating == 5): ?>
                                                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
                                            <?php elseif($record->review->rating == 4): ?>
                                                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i>
                                            <?php elseif($record->review->rating == 3): ?>
                                                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                            <?php elseif($record->review->rating == 2): ?>
                                                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                            <?php elseif($record->review->rating == 1): ?>
                                                <i class="fa fa-star"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i><i class="fa fa-star stroke-transparent"></i>
                                            <?php endif; ?>
                                            <?php else: ?>
                                                <a href="javascript:void(0)" class="text-danger">Not yet reviewed</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No Sales Record</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div class="p-3">
                                <div class="float-right">
                                    <?php echo e($sales_lists->appends(['search' => app('request')->input('search')])->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<!-- Bootstrap Select -->
<script src="<?php echo e(asset('js/cms/bootstrap-select.min.js')); ?>"></script>
<!-- Dropify -->
<script src="<?php echo e(asset('js/cms/dropify.min.js')); ?>"></script>
<!-- Sweetalert -->
<script src="<?php echo e(asset('js/cms/sweetalert.min.js')); ?>"></script>
<!-- Jquery Mask -->
<script src="<?php echo e(asset('js/cms/jquery.mask.min.js')); ?>"></script>
<!-- Custom JS -->
<script>
    function deleteProduct(idx) {
        swal({   
            title: "Are you sure?",   
            text: "You will not be able to recover this imaginary file!",   
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "Yes, delete it!",   
            cancelButtonText: "No, cancel!",   
            closeOnConfirm: false,   
            closeOnCancel: true 
        }, function(isConfirm){   
            if (isConfirm) {     
                var url = "<?php echo e(route('panel.product.delete', ['product' => "id"])); ?>";
                url = url.replace('id', idx);
                $.get(url, function( data ) {
                    swal({title : "Deleted!", text: "Product has been deleted.", type: "success"}, function() {
                        window.location.reload(true);
                    });   
                });
            }
        });
    }
    $(function () {
        'use strict'

        var ticksStyle = {
            fontColor: '#495057',
            fontStyle: 'bold'
        }

        var mode = 'index'
        var intersect = true

        <?php $__currentLoopData = $sales_of_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var temp_qty<?php echo e($key); ?> = 0;
            var temp_income<?php echo e($key); ?> = 0;
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                temp_qty<?php echo e($key); ?> += parseInt('<?php echo e($sale->quantity_order); ?>');
                temp_income<?php echo e($key); ?> += parseInt('<?php echo e($sale->quantity_order * $sale->product->price); ?>')
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            temp_income<?php echo e($key); ?> = "Rp " + parseInt((temp_income<?php echo e($key); ?>)/1000).toFixed(3);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        var max_quantity = 0;
        <?php $__currentLoopData = $sales_of_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            if(temp_qty<?php echo e($key); ?> > max_quantity)
                max_quantity = temp_qty<?php echo e($key); ?>

            $("#qty<?php echo e($key); ?>").text(temp_qty<?php echo e($key); ?>);
            $("#income<?php echo e($key); ?>").text(temp_income<?php echo e($key); ?>);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        var $salesChart = $('#sales-chart')
        var salesChart = new Chart($salesChart, {
            data: {
                // labels: ['18th', '20th', '22nd', '24th', '26th', '28th', '30th'],
                labels: [
                    <?php if(sizeof($sales_of_month) > 0): ?>
                    <?php $__currentLoopData = $sales_of_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($key); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                ],
                datasets: [{
                        type: 'line',
                        data: [
                            <?php $__currentLoopData = $sales_of_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                temp_qty<?php echo e($key); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                        backgroundColor: 'transparent',
                        borderColor: '#007bff',
                        pointBorderColor: '#007bff',
                        pointBackgroundColor: '#007bff',
                        fill: false
                        // pointHoverBackgroundColor: '#007bff',
                        // pointHoverBorderColor    : '#007bff'
                    },
                ]
            },
            options: {
                maintainAspectRatio: false,
                tooltips: {
                    mode: mode,
                    intersect: intersect
                },
                hover: {
                    mode: mode,
                    intersect: intersect
                },
                legend: {
                    display: false
                },
                scales: {
                    yAxes: [{
                        // display: false,
                        gridLines: {
                            display: true,
                            lineWidth: '4px',
                            color: 'rgba(0, 0, 0, .2)',
                            zeroLineColor: 'transparent'
                        },
                        ticks: $.extend({
                            beginAtZero: true,
                            suggestedMax: max_quantity+1
                        }, ticksStyle)
                    }],
                    xAxes: [{
                        display: true,
                        gridLines: {
                            display: false
                        },
                        ticks: ticksStyle
                    }]
                }
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/Admin/index.blade.php ENDPATH**/ ?>