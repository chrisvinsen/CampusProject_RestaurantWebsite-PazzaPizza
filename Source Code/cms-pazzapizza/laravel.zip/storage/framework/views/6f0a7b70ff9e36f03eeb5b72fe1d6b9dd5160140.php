

<?php $__env->startSection('custom_css'); ?>
<!-- Sweetalert -->
<link rel="stylesheet" href="<?php echo e(asset('css/cms/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- All Content -->
<main class="site-main">
    <!--================ Home Banner start =================-->
    <section class="hero-banner">
        <div class="container">
            <div class="row no-gutters align-items-center pt-60px">
                <div class="col-5 d-none d-sm-block">
                    <div class="hero-banner__img rounded img-hover-zoom">
                        <img class="img-fluid rounded shadow" src="<?php echo e(asset('images/cms/home_banner.jpg')); ?>" alt="Home Banner">
                    </div>
                </div>
                <div class="col-sm-7 col-lg-6 offset-lg-1 pl-4 pl-md-5 pl-lg-0">
                    <div class="hero-banner__content">
                        <h4>Pazza is Pizza</h4>
                        <h1>Pizza is Pazza</h1>
                        <p>Pizza is a dish of Italian origin consisting of a flat, round base of dough baked with a topping of tomato sauce and cheese, typically with added meat or vegetables.</p>
                        <a class="button button-hero" href="<?php echo e(route('menu')); ?>">Order Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ Home Banner end =================-->
    <!--================ Category Product section start =================-->
    <section class="mt-0 container">
        <div class="owl-carousel owl-theme hero-carousel">
            <?php $__currentLoopData = $category_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(sizeof($category->product) > 0): ?>
            <div class="hero-carousel__slide">
                <img src="<?php echo e($category->product[sizeof($category->product)-1]->image_url); ?>" alt="" class="img-fluid">
                <a href="#" class="hero-carousel__slideOverlay">
                    <h3><?php echo e($category->name); ?></h3>
                    <p><?php echo e($category->product[sizeof($category->product)-1]->name); ?></p>
                </a>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!--================ Category Product section end =================-->
    <!-- ================ New Menu section start ================= -->
    <section class="section-margin calc-60px">
        <div class="container">
            <div class="section-intro pb-60px">
                <p>Introducing our</p>
                <h2>New <span class="section-intro__style">Menu</span></h2>
            </div>
            <div class="row">
                <?php if(sizeof($new_product_lists) > 0): ?>
                <?php $__currentLoopData = $new_product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $new_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 col-xl-3">
                    <div class="card text-center card-product">
                        <div class="card-product__img">
                            <img class="card-img" src="<?php echo e($new_product->image_url); ?>" alt="">
                            <ul class="card-product__imgOverlay">
                                <li><a href="<?php echo e(route('menu.details', $new_product->id)); ?>"><button><i class="ti-search"></i></button></a></li>
                                <?php if($new_product->stock > 0): ?>
                                <li><a href="javascript:void(0)" onclick="addToCart(<?php echo e($new_product->id); ?>)"><button><i class="ti-shopping-cart"></i></button></a></li>
                                <?php endif; ?>
                                <li><a href="javascript:void(0)" onclick="addToFavorite(<?php echo e($new_product->id); ?>)"><button><i class="ti-heart"></i></button></a></li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <p><?php echo e($new_product->category->name); ?></p>
                            <h4 class="card-product__title"><a href="#"><?php echo e($new_product->name); ?></a></h4>
                            <p class="card-product__price">Rp <?php echo e(number_format($new_product->price,0,",",".")); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>There is no new Menu</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- ================ New Menu section end ================= -->
    <!-- ================ Offer section start ================= -->
    <section class="offer" id="parallax-1" data-anchor-target="#parallax-1" data-300-top="background-position: 20px 30px" data-top-bottom="background-position: 0 20px" style="background:url('<?php echo e(asset('images/cms/home_banner_paralax.jpg')); ?>') right center no-repeat;">
        <div class="container">
            <div class="row">
                <div class="col-xl-5">
                    <div class="offer__content text-center">
                        <h3 style="text-shadow: 2px 2px white;">FREE DELIVERY</h3>
                        <h4 style="text-shadow: 2px 2px white;">OPENING PROMOTIONS</h4>
                        <p style="text-shadow: 0.5px 0.5px white;">Pizza is Pazza, Pazza is Pizza</p>
                        <a class="button button--active mt-3 mt-xl-4" href="<?php echo e(route('menu')); ?>">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ================ Oferr section end ================= -->
    <!-- ================ Best Selling Menu Carousel start ================= -->
    <section class="section-margin calc-60px">
        <div class="container">
            <div class="section-intro pb-60px">
                <p>Popular Foods and Drinks</p>
                <h2>Best <span class="section-intro__style">Sellers</span></h2>
            </div>
            <?php if(sizeof($best_transaction_lists) > 0): ?>
            <div class="owl-carousel owl-theme" id="bestSellerCarousel">
                <?php $__currentLoopData = $best_transaction_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $best_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card text-center card-product">
                    <div class="card-product__img">
                        <img class="img-fluid" src="<?php echo e($best_transaction->product->image_url); ?>" alt="">
                        <ul class="card-product__imgOverlay">
                            <li><a href="<?php echo e(route('menu.details', $best_transaction->product->id)); ?>"><button><i class="ti-search"></i></button></a></li>
                            <?php if($best_transaction->product->stock > 0): ?>
                            <li><a href="javascript:void(0)" onclick="addToCart(<?php echo e($best_transaction->product->id); ?>)"><button><i class="ti-shopping-cart"></i></button></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:void(0)" onclick="addToFavorite(<?php echo e($best_transaction->product->id); ?>)"><button><i class="ti-heart"></i></button></a></li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <p><?php echo e($best_transaction->product->category->name); ?></p>
                        <h4 class="card-product__title"><a href="#"></a><?php echo e($best_transaction->product->name); ?></h4>
                        <p class="card-product__price"><?php echo e($best_transaction->product->price); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <p>There is no best selling Menu</p>
            <?php endif; ?>
        </div>
    </section>
    <!-- ================ Best Selling Menu Carousel end ================= -->
    <!-- ================ Quote section start ================= -->
    <section class="subscribe-position">
        <div class="container">
            <div class="subscribe text-center">
                <h3 class="subscribe__title">You Cant' Buy HAPPINESS, <br>But You Can Buy PIZZA <br>And That's Kind of The Same Thing</h3>
                <a class="button button-subscribe mr-auto mb-0 mt-3" href="<?php echo e(route('menu')); ?>">Order Now</a>
            </div>
        </div>
    </section>
    <!-- ================ Quote section end ================= -->
</main>
<!-- End of all content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<!-- Sweetalert -->
<script src="<?php echo e(asset('js/cms/sweetalert.min.js')); ?>"></script>
<!-- Custom JS -->
<script>
    function addToFavorite(idx) {

        data = new FormData();

        var url = "<?php echo e(route('account.favorite.store')); ?>";

        data.append('product_id', idx);

        $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            ajaxRequest = $.ajax({
                url: url,
                type: "POST",
                data: data,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data) {
                        swal({
                            title : "Success!", 
                            text: "Product Added to Favorite.", 
                            type: "success"
                        });
                        window.location.reload(true);
                    }
                },
                error: function(request, status, error) {
                    if (request.statusText == 'abort') {
                        return;
                    }
                    swal({
                        title : "Info!", 
                        text: request.responseJSON.messages, 
                        type: "info"
                    }, function(){
                        if(request.responseJSON.status == "login"){
                            window.top.location.href = "<?php echo e(route('account.login')); ?>"
                        }
                    });
                }
            });
    }

    function addToCart(idx) {

        data = new FormData();

        var url = "<?php echo e(route('menu.order.cart.store')); ?>";

        data.append('product_id', idx);
        data.append('quantity_order', 1);

        $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            ajaxRequest = $.ajax({
                url: url,
                type: "POST",
                data: data,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data) {
                        swal({
                            title : "Success!", 
                            text: "Product Added to Cart.", 
                            type: "success"
                        });
                        window.location.reload(true);
                    }
                },
                error: function(request, status, error) {
                    if (request.statusText == 'abort') {
                        return;
                    }
                    swal({
                        title : "Info!", 
                        text: request.responseJSON.messages, 
                        type: "info"
                    }, function(){
                        window.top.location.href = "<?php echo e(route('account.login')); ?>"
                    });
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/cms/home.blade.php ENDPATH**/ ?>