<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pazza Pizza - <?php echo e($title); ?></title>

    <!-- Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">

    <!-- ---------- Style ---------- -->

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/cms/bootstrap4/bootstrap.min.css')); ?>">
    <!-- Font awesome 5.12.1 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/cms/fontawesome-5.12.1/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cms/fontawesome-5.12.1/css/fontawesome.min.css')); ?>">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/themify-icons/themify-icons.css')); ?>">
    <!-- Linericon -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/linericon/style.css')); ?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/owl-carousel/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/owl-carousel/owl.carousel.min.css')); ?>">
    <!-- CSS Pages -->
    <link rel="stylesheet" href="<?php echo e(asset('css/cms/pages/style.css')); ?>">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/cms/custom.css')); ?>">
    <?php echo $__env->yieldContent('custom_css'); ?>
</head>
<body style="overflow-x: hidden;">
	<!-- Header -->
  	<?php echo $__env->make('cms.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    
    <!-- Content -->
  	<?php echo $__env->yieldContent('content'); ?>

    <!-- Scroll to Top -->
    <a id="scroll_to_top"><i class="fa fa-chevron-up text-white"></i></a>

    <!-- Footer -->
    <?php echo $__env->make('cms.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

    <!-- ---------- Script ---------- -->

    <!-- jQuery 3.4.1 -->
    <script src="<?php echo e(asset('js/cms/jquery-3.4.1/jquery-3.4.1.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('js/cms/bootstrap4/bootstrap.min.js')); ?>"></script>
    <!-- Skrollr -->
    <script src="<?php echo e(asset('plugins/skrollr.min.js')); ?>"></script>
    <!-- Owl Carousel -->
    <script src="<?php echo e(asset('plugins/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <!-- Nice Select -->
    <script src="<?php echo e(asset('plugins/nice-select/jquery.nice-select.min.js')); ?>"></script>
    <!-- jQuery Ajaxchimp -->
    <script src="<?php echo e(asset('plugins/jquery.ajaxchimp.min.js')); ?>"></script>
    <!-- Mail Script -->
    <script src="<?php echo e(asset('plugins/mail-script.js')); ?>"></script>
    <!-- JS Pages -->
    <script src="<?php echo e(asset('js/cms/pages.js')); ?>"></script>
	<?php echo $__env->yieldContent('custom_js'); ?>
</body>
</html><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/cms/layouts/base.blade.php ENDPATH**/ ?>