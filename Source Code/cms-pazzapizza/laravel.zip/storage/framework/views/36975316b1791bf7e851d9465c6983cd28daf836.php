
<?php $__env->startSection('title','product Detail'); ?>
<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Product Details</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Product Detail</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><?php echo e($product->name); ?></h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 p-4">
                        <img class="w-100" src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">
                            <h3 class="mb-4">Product Information</h3>
                            <div class="form-group">
                                <label for="category">Name</label>
                                <p><?php echo e($product->name); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="category">Category</label>
                                <p><?php echo e($product->category->name); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="price">Price</label>
                                <p><?php echo e($product->price); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="price">Stock</label>
                                <p><?php echo e($product->stock); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <p><?php echo e($product->description); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right p-3">
                    <a href="<?php echo e(route('panel')); ?>" class="btn btn-outline-secondary mx-1">Back</a>
                    <a href="<?php echo e(route('panel.product.update', $product->id)); ?>" class="btn btn-outline-primary mx-1">Edit products</a>
                    <!-- <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-secondary">Cancel</a> -->
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thinkpad\Documents\Projects\Multimedia Nusantara University\Restaurant_PazzaPizza\cms-pazzapizza\resources\views/Admin/detail.blade.php ENDPATH**/ ?>